#School Attendance AI Model
# Logistic Regression Model

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split, StratifiedKFold, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, precision_score,
                             recall_score, roc_auc_score,
                             confusion_matrix)

RAW_DATA = "School_Attendance_dataset.csv"
CLEAN_DATA = "School_Attendance_dataset_cleaned.csv"

# Load data and drop columns that aren't helpful for the AI analysis
df_raw = pd.read_csv(RAW_DATA)
df_raw = df_raw.drop(columns=["District code", "District name", "Reporting period", "Date update"])

# define the at-risk target (attendance < 90%)
target_column = "2021-2022 attendance rate - year to date"

# 1 = at-risk, 0 = not at-risk
y = (df_raw[target_column] < 90).astype(int)

# define the features
x = df_raw.drop(columns=[target_column])

# fill in the missing values with the median of each column
for column in x.select_dtypes(include=["float64", "int64"]).columns:
    x[column] = x[column].fillna(df_raw[column].median())

# fill in the missing text with "unknown"
for column in x.select_dtypes(include=["object"]).columns:
    x[column] = x[column].fillna("Unknown")

# convert non-numeric categories to numbers using one-hot encoding
x = pd.get_dummies(x, drop_first=True)

# normalize numeric values so that they are using the same scale
scaler = StandardScaler()
num_columns = x.select_dtypes(include=["float64", "int64"]).columns
x[num_columns] = scaler.fit_transform(x[num_columns])

# select columns for clustering
attendance_columns = [
    "2021-2022 attendance rate - year to date",
    "2020-2021 attendance rate",
    "2019-2020 attendance rate"
]
attendance_df = df_raw[attendance_columns].copy()
attendance_df = attendance_df.fillna(attendance_df.median())

attendance_scaler = StandardScaler()
attendance_std = attendance_scaler.fit_transform(attendance_df)

# run Kmeans with 3 clusters
kmeans = KMeans(n_clusters=3, n_init=10, random_state=42)
attendance_cluster = kmeans.fit_predict(attendance_std)

print(pd.Series(attendance_cluster,
                name="attendance_cluster").value_counts())

print("\nCluster centers: ")
print(kmeans.cluster_centers_)

# Add cluster label as a feature (simple integer; you could one-hot it if you like)
x["attendance_cluster"] = attendance_cluster

# Save a single cleaned table for convenience (features + raw target for reference)
out = x.copy()
out[target_column] = df_raw[target_column].values  # keep raw % for reference
out.to_csv(CLEAN_DATA, index=False)
print(f"\nData cleaned. Saved {CLEAN_DATA}\n")




# The Logistic Regression Model

# load the clean dataset
df = pd.read_csv("School_Attendance_dataset_cleaned.csv")
target_column = "2021-2022 attendance rate - year to date"

# target from RAW_DATA % stored in the cleaned CSV
y = (df[target_column] < 90).astype(int)

# drop the raw target column feature
x = df.drop(columns=[target_column])

# split into train/test sets (80% train, 20% test)
x_train, x_test, y_train, y_test = train_test_split(x, y,
                                                    test_size=0.2,
                                                    random_state=42,
                                                    stratify=y)

# tiny hyperparameter search (optimize for recall)
param_grid = {"C": [0.05, 0.1, 0.5, 1.0, 2.0]}
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

grid = GridSearchCV(
    LogisticRegression(max_iter=500, solver="liblinear", class_weight="balanced"),
    param_grid = param_grid,
    scoring = "recall",
    cv = cv,
    n_jobs=-1
)
grid.fit(x_train, y_train)
clf = grid.best_estimator_
print("Best C from CV: ", grid.best_params_["C"])

# predict probabilities, then tune decision threshold for better recall
y_prob = clf.predict_proba(x_test)[:, 1]
best_threshold, best_recall, best_precision = .50, 0.0, 0.0
for threshold in np.linspace(.30, .70, 9):
    y_pred_t = (y_prob >= threshold).astype(int)
    recall = recall_score(y_test, y_pred_t, zero_division=0)
    precision = precision_score(y_test, y_pred_t, zero_division=0)
    if recall > best_recall:
        best_threshold, best_recall, best_precision = threshold, recall, precision


# evaluate the model
y_pred = (y_prob >= best_threshold).astype(int)
print(f"Chosen threshold: {best_threshold: .2f}")
print("Accuracy: ", round(accuracy_score(y_test, y_pred), 3))
print("Precision: ", round(precision_score(y_test, y_pred), 3))
print("Recall: ", round(recall_score(y_test, y_pred), 3))
print("ROC-AUC: ", round(roc_auc_score(y_test, y_prob), 3))
print("Confusion matrix: ", confusion_matrix(y_test, y_pred))

# see which features are most important
coefficient_table = pd.DataFrame({
    "Feature": x.columns,
    "Coefficient": clf.coef_[0],
    "Abs_Coefficient": np.abs(clf.coef_[0])
}).sort_values(by="Abs_Coefficient", ascending=False)

print("\nTop 10 most important features: ")
print(coefficient_table.head(10))


# small part to check for fairness by subgroup

def by_group_stats(df_eval, group_column):
    rows = []
    for g, d in df_eval.groupby(group_column):
        rows.append({
            group_column: g,
            "n": len(d),
            "precision": precision_score(d["y_true"], d["y_pred"], zero_division=0),
            "recall": recall_score(d["y_true"], d["y_pred"], zero_division=0),
        })
    return pd.DataFrame(rows).sort_values("n", ascending=False)

# example fairness check for homeless students
# can check other subgroups by changing from homeless to subgroup desired
eval_df = pd.DataFrame({"y_true": y_test, "y_pred": y_pred, "homeless": x_test["Category_Homelessness"]})
print("\nFairness Check for Homeless Students: ")
print(by_group_stats(eval_df, "homeless"))